#include <pthread.h>
#include "sync_car.h"

void station_init(struct station *station)
{
	pthread_mutex_init(&station->lock, NULL);
	pthread_cond_init(&station->car_arrived, NULL);
	pthread_cond_init(&station->car_loaded, NULL);
	station->waiting = 0;
	station->free_seats = 0;
	station->boarding = 0;
}

/*
 * Chamada pelo carro. Retorna quando:
 *  - nao ha mais ninguem embarcando (boarding == 0), E
 *  - o carro esta cheio (free_seats == 0) OU nao ha mais passageiros esperando.
 */
void station_load_car(struct station *station, int count)
{
	pthread_mutex_lock(&station->lock);

	station->free_seats = count;
	/* acorda todos os passageiros: cada um verifica se ainda ha assento */
	pthread_cond_broadcast(&station->car_arrived);

	while ((station->free_seats > 0 && station->waiting > 0) ||
	       station->boarding > 0)
		pthread_cond_wait(&station->car_loaded, &station->lock);

	/* carro saindo: nenhum assento disponivel ate o proximo carro */
	station->free_seats = 0;

	pthread_mutex_unlock(&station->lock);
}

/*
 * Chamada pelo passageiro. Retorna quando ha um carro na estacao
 * com assento livre, e ja reserva esse assento.
 */
void station_wait_for_car(struct station *station)
{
	pthread_mutex_lock(&station->lock);

	station->waiting++;
	while (station->free_seats == 0)
		pthread_cond_wait(&station->car_arrived, &station->lock);

	/* reserva o assento */
	station->waiting--;
	station->free_seats--;
	station->boarding++;

	pthread_mutex_unlock(&station->lock);
}

/*
 * Chamada depois que o passageiro sentou. Se ele foi o ultimo
 * que faltava e o carro ja pode partir, acorda o carro.
 */
void station_on_board(struct station *station)
{
	pthread_mutex_lock(&station->lock);

	station->boarding--;
	if (station->boarding == 0 &&
	    (station->free_seats == 0 || station->waiting == 0))
		pthread_cond_signal(&station->car_loaded);

	pthread_mutex_unlock(&station->lock);
}
