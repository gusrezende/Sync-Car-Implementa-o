#ifndef SYNC_CAR_H
#define SYNC_CAR_H

#include <pthread.h>

struct station {
	pthread_mutex_t lock;          /* unico lock da estacao */
	pthread_cond_t  car_arrived;   /* passageiros esperam aqui por um carro com assentos */
	pthread_cond_t  car_loaded;    /* o carro espera aqui o embarque terminar */
	int waiting;                   /* passageiros esperando na plataforma */
	int free_seats;                /* assentos livres no carro atual (0 = sem carro) */
	int boarding;                  /* passageiros liberados que ainda nao chamaram on_board */
};

void station_init(struct station *station);
void station_load_car(struct station *station, int count);
void station_wait_for_car(struct station *station);
void station_on_board(struct station *station);

#endif
