/*
 * Testes extras para sync_car.c (complementam o sync_car-runner.c do professor).
 *  T1 (caso invalido): carro com assentos NEGATIVOS e sem passageiros -> retorna na hora.
 *  T2 (caso invalido): carro com assentos negativos e passageiros esperando -> ninguem embarca.
 *  T3 (caso limite):   todos saem de wait_for_car antes de qualquer on_board (requisito 5).
 *  T4 (caso limite):   carro com mais assentos que passageiros -> parte quando a plataforma esvazia.
 */
#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <unistd.h>
#include <pthread.h>
#include "sync_car.h"

static struct station st;
static volatile int embarcaram = 0;
static volatile int carro_partiu = 0;

static void *passageiro(void *arg)
{
    (void) arg;
    station_wait_for_car(&st);
    __sync_add_and_fetch(&embarcaram, 1);
    return NULL;
}

struct carro_args { int assentos; };

static void *carro(void *arg)
{
    struct carro_args *a = arg;
    station_load_car(&st, a->assentos);
    carro_partiu = 1;
    return NULL;
}

static const char *teste_atual = "";
static void timeout(int sig)
{
    (void) sig;
    fprintf(stderr, "FALHOU (timeout/deadlock) em: %s\n", teste_atual);
    exit(1);
}

static void falha(const char *msg)
{
    fprintf(stderr, "FALHOU em %s: %s\n", teste_atual, msg);
    exit(1);
}

static void cria_passageiros(int n)
{
    for (int i = 0; i < n; i++) {
        pthread_t t;
        if (pthread_create(&t, NULL, passageiro, NULL) != 0) {
            perror("pthread_create");
            exit(1);
        }
        pthread_detach(t);
    }
    usleep(100000);
}

static pthread_t chega_carro(struct carro_args *a)
{
    pthread_t t;
    carro_partiu = 0;
    if (pthread_create(&t, NULL, carro, a) != 0) {
        perror("pthread_create");
        exit(1);
    }
    return t;
}

int main(void)
{
    signal(SIGALRM, timeout);
    station_init(&st);

    teste_atual = "T1 (assentos negativos, sem passageiros)";
    alarm(2);
    station_load_car(&st, -5);
    alarm(0);
    printf("OK  %s\n", teste_atual);

    teste_atual = "T2 (assentos negativos, 3 passageiros esperando)";
    alarm(2);
    cria_passageiros(3);
    station_load_car(&st, -1);
    usleep(100000);
    if (embarcaram != 0)
        falha("passageiro embarcou em carro com assentos negativos");
    alarm(0);
    printf("OK  %s\n", teste_atual);

    teste_atual = "T3 (3 assentos, 3 passageiros, embarque simultaneo)";
    alarm(2);
    struct carro_args a3 = {3};
    pthread_t c3 = chega_carro(&a3);
    while (embarcaram < 3)
        usleep(1000);
    usleep(50000);
    if (carro_partiu)
        falha("carro partiu antes dos station_on_board");
    for (int i = 0; i < 3; i++)
        station_on_board(&st);
    pthread_join(c3, NULL);
    alarm(0);
    printf("OK  %s\n", teste_atual);

    teste_atual = "T4 (10 assentos, 2 passageiros)";
    embarcaram = 0;
    alarm(2);
    cria_passageiros(2);
    struct carro_args a4 = {10};
    pthread_t c4 = chega_carro(&a4);
    while (embarcaram < 2)
        usleep(1000);
    station_on_board(&st);
    station_on_board(&st);
    pthread_join(c4, NULL);
    alarm(0);
    if (embarcaram != 2)
        falha("numero errado de passageiros");
    printf("OK  %s\n", teste_atual);

    printf("Todos os testes extras passaram!\n");
    return 0;
}
